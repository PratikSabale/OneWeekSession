package Days;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class CustomerManagementSystem7_8 {
    private static class Customer {
        String id;
        String name;
        String email;

        Customer(String id, String name, String email) {
            this.id = id;
            this.name = name;
            this.email = email;
        }

        @Override
        public String toString() {
            return "ID: " + id + ", Name: " + name + ", Email: " + email;
        }
    }

    private static ArrayList<Customer> custList = new ArrayList<>();

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int ch;

        do {
            System.out.println("1. Add a Customer\n2. Remove a Customer\n3. Search for a Customer\n4. List All Customers\n5. Sort Customers by Name\n6. Sort Customers by ID\n7. Exit");
            System.out.println("Enter Your Choice: ");
            ch = sc.nextInt();
           

            switch (ch) {
                case 1:
                    addCustomer(sc);
                    break;
                case 2:
                    removeCustomer(sc);
                    break;
                case 3:
                    searchCustomer(sc);
                    break;
                case 4:
                    listAllCust();
                    break;
                case 5:
                    sortByName();
                    break;
                case 6:
                    sortById();
                    break;
                case 7:
                    System.out.println("Exit");
                    break;
                default:
                    System.out.println("Enter Proper Choice");
            }
        } while (ch != 7);

    
    }

    private static void addCustomer(Scanner sc) {
        System.out.print("Enter Unique ID: ");
        String id = sc.next();
        System.out.print("Enter Name: ");
        String name = sc.next();
        System.out.print("Enter Email: ");
        String email = sc.next();

        Customer customer = new Customer(id, name, email);
        custList.add(customer);

        System.out.println("\n...Customer Added Successfully...\n");
    }

    private static void removeCustomer(Scanner sc) {
        System.out.print("Enter ID to remove customer: ");
        String id = sc.next();

        boolean found = false;
        for (Customer customer : custList) {
            if (customer.id.equals(id)) {
                custList.remove(customer);
                System.out.println("\n...Customer Removed Successfully...\n");
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Customer with ID " + id + " not found.");
        }
    }

    private static void searchCustomer(Scanner sc) {
        System.out.print("Enter customer name to search: ");
        String name = sc.next();

        boolean found = false;
        for (Customer customer : custList) {
            if (customer.name.equalsIgnoreCase(name)) {
                System.out.println("Customer found: " + customer);
                found = true;
            }
        }

        if (!found) {
            System.out.println("Customer with name " + name + " not found.");
        }
    }

    private static void listAllCust() {
        System.out.println("List of all Customers:");
        for (Customer customer : custList) {
            System.out.println(customer);
        }
    }

    private static void sortByName() {
        Collections.sort(custList, (c1, c2) -> c1.name.compareToIgnoreCase(c2.name));
        System.out.println("Customer List sorted by name:");
        listAllCust();
    }

    private static void sortById() {
        Collections.sort(custList, (c1, c2) -> c1.id.compareTo(c2.id));
        System.out.println("Customer List sorted by ID:");
        listAllCust();
    }
}
