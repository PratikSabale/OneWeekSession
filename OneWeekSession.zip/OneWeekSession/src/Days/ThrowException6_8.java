package Days;
import java.util.Scanner;

class NegativeAmount extends RuntimeException{
	
	public NegativeAmount(String s) {
		super(s);
	}
}

class InsufficientFund extends RuntimeException{
	
	public InsufficientFund(String s) {
		super(s);
	}
}




public class ThrowException6_8 {
	public static int bal=0;
	public static void main(String [] args) 
	{
		Scanner sc=new Scanner(System.in);
		int c;
		
		do {
			
			System.out.println("1.Deposit Money\n2.WithDraw Money\n3.Check Balance\n4.Exit");
			System.out.println("Please Enter Your Choice : ");
			c=sc.nextInt();
			switch(c) {
			case 1:
				depositMoney(sc);
				break;
				
			case 2:
				withDrawMoney(sc);
				break;
				
			case 3:
				checkBalance(sc);
				break;
				
			case 4:
				System.out.println("Exit");
				break;
				
				default:
					System.out.println("Please Enter Valid Choice !!");
			}}while(c!=4);
			 		

		}
		public static void depositMoney(Scanner sc)
		{
			System.out.println("Enter Deposit Amount Here : ");
		   int amount=sc.nextInt();
		   bal=bal+amount;
			System.out.println("Amount Deposited Successfully!!");
			
		}
		
		public static void withDrawMoney(Scanner sc)
		{
			System.out.println("Enter Amount to WithDraw :");
			int amount=sc.nextInt();
			if(amount<1) {
				throw new NegativeAmount("Your not able Withdraw More Money");
			}
			else if(amount>bal){
				throw new InsufficientFund("You Are Not Able To WithDraw More Money Than Your Acount Balance");
			}
			else if(bal>amount) {
				System.out.println("Money Withdraw Successfully!!");
				bal=bal-amount;
			}
			else {
				System.out.println("Sorry,");
			}
		}

		public static void checkBalance(Scanner sc ) 
		{
			System.out.println(" your Balance : "+bal);
			
		}

		}
		

